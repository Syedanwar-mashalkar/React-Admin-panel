import './Dashboard.css';
import { Link } from 'react-router-dom';
function Dashboard() {
  return (
    <div>
      <div className="side-menu">
        <div className="brand-name">
          <h1>Brand</h1>
        </div>
        <ul>
        
          <li><span>
          <Link class="nav-link" to="/">Dashboard</Link></span></li>
          <li><span><Link class="nav-link" to="/Students">Students</Link></span></li>
          <li><span><Link class="nav-link" to="/Teachers">Teachers</Link></span></li>
          <li><span><Link class="nav-link" to="/Schools">Schools</Link></span></li>
          <li><span><Link class="nav-link" to="/Income">Income</Link></span></li>
          <li><span><Link class="nav-link" to="/Help">Help</Link></span></li>
          <li><span><Link class="nav-link" to="/Settings">Settings</Link></span></li>
        </ul>
      </div>
      
      <div className="container">
        <div className="header">
          <div className="nav">
            <div className="search">
              <input type="text" placeholder="Search.." />
              <button type="submit"></button>
            </div>
            <div className="user">
            <Link class="btn" to="/addnew">Add new</Link>
              <div className="img-case"></div>
            </div>
          </div>
        </div>
        
        <div className="content">
          <div className="cards">
            <div className="card">
              <div className="box">
                <h1>2194</h1>
                <h3>Students</h3>
              </div>
              <div className="icon-case"></div>
            </div>
            <div className="card">
              <div className="box">
                <h1>53</h1>
                <h3>Teachers</h3>
              </div>
              <div className="icon-case"></div>
            </div>
            <div className="card">
              <div className="box">
                <h1>5</h1>
                <h3>Schools</h3>
              </div>
              <div className="icon-case"></div>
            </div>
            <div className="card">
              <div className="box">
                <h1>350000</h1>
                <h3>Income</h3>
              </div>
              <div className="icon-case"></div>
            </div>
          </div>
          
          <div className="content-2">
            <div className="recent-payments">
              <div className="title">
                <h2>Recent Payments</h2>
                <a href="#" className="btn">View All</a>
              </div>
              <table>
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>School</th>
                    <th>Amount</th>
                    <th>Option</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>John Doe</td>
                    <td>St. James College</td>
                    <td>$120</td>
                    <td><a href="#" className="btn">View</a></td>
                  </tr>
                  <tr>
                    <td>John Doe</td>
                    <td>St. James College</td>
                    <td>$120</td>
                    <td><a href="#" className="btn">View</a></td>
                  </tr>
                  <tr>
                    <td>John Doe</td>
                    <td>St. James College</td>
                    <td>$120</td>
                    <td><a href="#" className="btn">View</a></td>
                  </tr>
                  <tr>
                    <td>John Doe</td>
                    <td>St. James College</td>
                    <td>$120</td>
                    <td><a href="#" className="btn">View</a></td>
                  </tr>
                  <tr>
                    <td>John Doe</td>
                    <td>St. James College</td>
                    <td>$120</td>
                    <td><a href="#" className="btn">View</a></td>
                  </tr>
                  <tr>
                    <td>John Doe</td>
                    <td>St. James College</td>
                    <td>$120</td>
                    <td><a href="#" className="btn">View</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
